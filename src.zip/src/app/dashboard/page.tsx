import Link from "next/link";
import {
  Activity,
  ArrowRight,
  Flame,
  ShieldCheck,
  Target,
  Utensils,
} from "lucide-react";
import { AIInsightCard } from "@/components/dashboard/AIInsightCard";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { MacroDistributionCard } from "@/components/dashboard/MacroDistributionCard";
import { MealCard } from "@/components/meal-plan/MealCard";
import { StatCard } from "@/components/dashboard/StatCard";
import { Badge } from "@/components/ui/Badge";
import { buttonStyles } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { mockAIInsight, mockNutritionSummary } from "@/data";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const profile = user
    ? await prisma.userProfile.findUnique({
        where: { userId: user.id },
        include: {
          allergies: { include: { allergen: true } },
        },
      })
    : null;
  const mealPlan = user
    ? await prisma.mealPlan.findFirst({
        where: { userId: user.id },
        orderBy: { createdAt: "desc" },
        include: {
          items: {
            where: { dayNumber: 1 },
            include: { food: true },
            take: 2,
          },
        },
      })
    : null;
  const bmr = profile?.bmr ?? mockNutritionSummary.bmr;
  const tdee = profile?.tdee ?? mockNutritionSummary.tdee;
  const targetCalories =
    profile?.targetCalories ?? mockNutritionSummary.calorieTarget;
  const allergyLabels =
    profile?.allergies.map((a) => a.allergen.name) ?? [];

  const userName = user?.user_metadata?.name ?? "User";
  const day1Meals = mealPlan?.items.map((item) => ({
    id: item.id,
    name: item.food.name,
    type: item.mealType,
    calories: item.calories,
    protein: item.proteinG,
    carbs: item.carbsG,
    fat: item.fatG,
    image: "/placeholder-food.jpg",
    ingredients: [],
    allergyAnalysis: "Verified allergy-safe",
    fitReason: `${item.servingG}g serving`,
  })) ?? [];

  return (
    <DashboardShell>
      <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:py-8">
        <div className="mb-6 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
          <div>
            <p className="text-sm font-semibold text-brand-700">Dashboard</p>
            <h1 className="mt-2 text-3xl font-bold tracking-normal text-ink">
              Welcome back, {userName.split(" ")[0]}
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-muted">
              Your nutrition targets, allergy filters, and recommendation
              previews are ready.
            </p>
          </div>
          <Link href="/meal-plan" className={buttonStyles({ size: "lg" })}>
            Generate 7-Day Meal Plan <ArrowRight className="h-5 w-5" />
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <StatCard
            title="Daily calorie target"
            value={`${Math.round(targetCalories)}`}
            helper="Maintenance-adjusted daily intake"
            badge="Today"
            icon={Target}
            tone="green"
          />
          <StatCard
            title="BMR"
            value={`${Math.round(bmr)}`}
            helper="Estimated calories at rest"
            icon={Flame}
            tone="amber"
          />
          <StatCard
            title="TDEE"
            value={`${Math.round(tdee)}`}
            helper="Estimated daily energy expenditure"
            icon={Activity}
            tone="blue"
          />
        </div>

        <div className="mt-4 grid gap-4 xl:grid-cols-[1fr_0.9fr]">
          <MacroDistributionCard summary={mockNutritionSummary} />
          <Card>
            <CardContent>
              <div className="flex items-start gap-3">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
                  <ShieldCheck className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-sm font-semibold text-brand-700">
                    Allergy safety status
                  </p>
                  <h2 className="mt-1 text-xl font-bold text-ink">
                    {allergyLabels.length > 0
                      ? "Active filtering enabled"
                      : "No filters active"}
                  </h2>
                  <p className="mt-3 text-sm leading-6 text-muted">
                    Recommendations exclude meals that contain or commonly rely
                    on your selected allergy groups.
                  </p>
                </div>
              </div>
              <div className="mt-5 flex flex-wrap gap-2">
                {allergyLabels.length > 0 ? (
                  allergyLabels.map((label) => (
                    <Badge key={label} variant="safe">
                      {label}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-muted">
                    Belum ada alergi dipilih.{" "}
                    <Link href="/profile" className="font-semibold text-brand-700">
                      Update profil
                    </Link>
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-4 grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">
          <AIInsightCard insight={mockAIInsight} />
          <Card>
            <CardContent>
              <div className="mb-5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-brand-700">
                    Recent recommendation preview
                  </p>
                  <h2 className="mt-1 text-xl font-bold text-ink">
                    Day 1 highlights
                  </h2>
                </div>
                <Utensils className="h-5 w-5 text-slate-400" />
              </div>

              {day1Meals.length > 0 ? (
                <div className="grid gap-4 md:grid-cols-2">
                  {day1Meals.slice(0, 2).map((meal) => (
                    <MealCard key={meal.id} meal={meal as never} />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-slate-200 py-10 text-center">
                  <Utensils className="h-8 w-8 text-slate-300" />
                  <p className="mt-3 text-sm font-semibold text-ink">
                    Belum ada meal plan
                  </p>
                  <p className="mt-1 text-sm text-muted">
                    Generate meal plan pertama kamu untuk melihat preview di
                    sini.
                  </p>
                  <Link
                    href="/meal-plan"
                    className={buttonStyles({ size: "sm", className: "mt-4" })}
                  >
                    Generate sekarang
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  );
}
