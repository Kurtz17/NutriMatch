"use client";

import { useMemo, useState, useEffect, useCallback } from "react";
import {
  RefreshCcw,
  ShieldCheck,
  Sparkles,
  TriangleAlert,
  X,
} from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { MacroDistributionCard } from "@/components/dashboard/MacroDistributionCard";
import { MealCard } from "@/components/meal-plan/MealCard";
import { MealPlanTabs } from "@/components/meal-plan/MealPlanTabs";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { mockNutritionSummary } from "@/data";
import type { Meal } from "@/types";

interface ApiMealItem {
  id: string;
  dayNumber: number;
  mealType: string;
  servingG: number;
  calories: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
  food: { id: string; name: string; category: string | null };
}

interface ApiDay {
  dayNumber: number;
  totalCalories: number;
  totalProteinG: number;
  totalCarbsG: number;
  totalFatG: number;
  meals: {
    BREAKFAST: ApiMealItem[];
    LUNCH: ApiMealItem[];
    DINNER: ApiMealItem[];
    SNACK: ApiMealItem[];
  };
}

function toMealCardShape(item: ApiMealItem): Meal {
  return {
    id: item.id,
    name: item.food.name,
    type: item.mealType as Meal["type"],
    calories: item.calories,
    protein: item.proteinG,
    carbs: item.carbsG,
    fat: item.fatG,
    image: "/placeholder-food.jpg",
    ingredients: [],
    allergyAnalysis: "Verified allergy-safe by NutriMatch filter",
    fitReason: `${item.servingG}g serving · ${item.food.category ?? ""}`,
  };
}

export default function MealPlanPage() {
  const [activeDay, setActiveDay] = useState(1);
  const [selectedMeal, setSelectedMeal] = useState<Meal | null>(null);
  const [days, setDays] = useState<ApiDay[]>([]);
  const [targetCalories, setTargetCalories] = useState(0);
  const [allergyCount, setAllergyCount] = useState(0);

  const [fetchState, setFetchState] = useState<
    "loading" | "empty" | "ready" | "error"
  >("loading");
  const [generating, setGenerating] = useState(false);
  const [swappingId, setSwappingId] = useState<string | null>(null);

  const fetchMealPlan = useCallback(async () => {
    try {
      const res = await fetch("/api/meal-plan");
      if (res.status === 404) {
        setFetchState("empty");
        return;
      }
      if (!res.ok) {
        setFetchState("error");
        return;
      }
      const data = await res.json();
      setDays(data.mealPlan.days);
      setTargetCalories(data.mealPlan.targetCalories);
      setFetchState("ready");
    } catch {
      setFetchState("error");
    }
  }, []);

  useEffect(() => {
    fetch("/api/profile")
      .then((r) => r.json())
      .then((d) => setAllergyCount(d.profile?.allergies?.length ?? 0))
      .catch(() => {});
  }, []);

  useEffect(() => {
    fetchMealPlan();
  }, [fetchMealPlan]);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const res = await fetch("/api/meal-plan", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error ?? "Gagal generate meal plan");
        return;
      }
      await fetchMealPlan();
    } catch {
      alert("Terjadi kesalahan. Coba lagi.");
    } finally {
      setGenerating(false);
    }
  };

  const handleSwap = async (itemId: string) => {
    setSwappingId(itemId);
    try {
      const res = await fetch(`/api/meal-plan/item/${itemId}`, {
        method: "PATCH",
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error ?? "Tidak ada makanan pengganti tersedia");
        return;
      }
      setDays((prev) =>
        prev.map((day) => ({
          ...day,
          meals: {
            BREAKFAST: day.meals.BREAKFAST.map((i) =>
              i.id === itemId
                ? {
                    ...i,
                    foodId: data.newItem.food.id,
                    food: data.newItem.food,
                    servingG: data.newItem.servingG,
                    calories: data.newItem.calories,
                    proteinG: data.newItem.proteinG,
                    carbsG: data.newItem.carbsG,
                    fatG: data.newItem.fatG,
                  }
                : i
            ),
            LUNCH: day.meals.LUNCH.map((i) =>
              i.id === itemId
                ? {
                    ...i,
                    food: data.newItem.food,
                    servingG: data.newItem.servingG,
                    calories: data.newItem.calories,
                    proteinG: data.newItem.proteinG,
                    carbsG: data.newItem.carbsG,
                    fatG: data.newItem.fatG,
                  }
                : i
            ),
            DINNER: day.meals.DINNER.map((i) =>
              i.id === itemId
                ? {
                    ...i,
                    food: data.newItem.food,
                    servingG: data.newItem.servingG,
                    calories: data.newItem.calories,
                    proteinG: data.newItem.proteinG,
                    carbsG: data.newItem.carbsG,
                    fatG: data.newItem.fatG,
                  }
                : i
            ),
            SNACK: day.meals.SNACK.map((i) =>
              i.id === itemId
                ? {
                    ...i,
                    food: data.newItem.food,
                    servingG: data.newItem.servingG,
                    calories: data.newItem.calories,
                    proteinG: data.newItem.proteinG,
                    carbsG: data.newItem.carbsG,
                    fatG: data.newItem.fatG,
                  }
                : i
            ),
          },
        }))
      );
      if (selectedMeal?.id === itemId) setSelectedMeal(null);
    } catch {
      alert("Terjadi kesalahan. Coba lagi.");
    } finally {
      setSwappingId(null);
    }
  };

  const currentDay = useMemo(
    () => days.find((d) => d.dayNumber === activeDay) ?? days[0],
    [days, activeDay]
  );

  const weeklyCalories = useMemo(
    () => days.reduce((sum, d) => sum + d.totalCalories, 0),
    [days]
  );
  const tabDays = days.map((d) => ({
    day: d.dayNumber,
    calories: d.totalCalories,
    meals: [
      ...d.meals.BREAKFAST,
      ...d.meals.LUNCH,
      ...d.meals.DINNER,
      ...d.meals.SNACK,
    ].map(toMealCardShape),
  }));
  const currentMeals = currentDay
    ? [
        ...currentDay.meals.BREAKFAST,
        ...currentDay.meals.LUNCH,
        ...currentDay.meals.DINNER,
        ...currentDay.meals.SNACK,
      ].map(toMealCardShape)
    : [];

  return (
    <DashboardShell>
      <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:py-8">
        <div className="mb-6 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
          <div>
            <p className="text-sm font-semibold text-brand-700">
              7-day meal plan
            </p>
            <h1 className="mt-2 text-3xl font-bold tracking-normal text-ink">
              Allergy-safe weekly recommendations
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-muted">
              Browse breakfast, lunch, dinner, and snack options generated from
              your saved profile.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="safe">
              <ShieldCheck className="h-3.5 w-3.5" />
              {allergyCount} allergy filters active
            </Badge>
            <Button onClick={handleGenerate} disabled={generating}>
              <RefreshCcw className="h-4 w-4" />
              {generating ? "Generating..." : "Generate ulang"}
            </Button>
          </div>
        </div>
        {fetchState === "loading" && (
          <div className="py-24 text-center text-sm text-muted">
            Memuat meal plan...
          </div>
        )}
        {fetchState === "empty" && (
          <Card>
            <CardContent className="flex flex-col items-center py-16 text-center">
              <Sparkles className="h-10 w-10 text-brand-300" />
              <h2 className="mt-4 text-xl font-bold text-ink">
                Belum ada meal plan
              </h2>
              <p className="mt-2 max-w-sm text-sm leading-6 text-muted">
                Generate meal plan 7 hari pertama kamu. Semua makanan sudah
                disesuaikan dengan profil dan alergi yang kamu pilih.
              </p>
              <Button
                className="mt-6"
                size="lg"
                onClick={handleGenerate}
                disabled={generating}
              >
                <Sparkles className="h-5 w-5" />
                {generating ? "Generating..." : "Generate Meal Plan"}
              </Button>
            </CardContent>
          </Card>
        )}
        {fetchState === "error" && (
          <Card className="border-red-100 bg-red-50">
            <CardContent>
              <p className="text-sm font-semibold text-red-700">
                Gagal memuat meal plan. Pastikan kamu sudah mengisi profil fisik
                terlebih dahulu.
              </p>
            </CardContent>
          </Card>
        )}
        {fetchState === "ready" && currentDay && (
          <div className="grid gap-4 xl:grid-cols-[1fr_380px]">
            <div className="min-w-0">
              <MealPlanTabs
                days={tabDays}
                activeDay={activeDay}
                onChange={setActiveDay}
              />
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {currentMeals.map((meal) => (
                  <MealCard
                    key={meal.id}
                    meal={meal}
                    onOpen={setSelectedMeal}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Card>
                <CardContent>
                  <p className="text-sm font-semibold text-brand-700">
                    Weekly nutrition summary
                  </p>
                  <h2 className="mt-1 text-xl font-bold text-ink">
                    {weeklyCalories.toLocaleString()} kcal
                  </h2>
                  <p className="mt-3 text-sm leading-6 text-muted">
                    Target harian: {Math.round(targetCalories)} kcal. Rata-rata
                    aktual:{" "}
                    {days.length > 0
                      ? Math.round(weeklyCalories / days.length)
                      : 0}{" "}
                    kcal.
                  </p>
                  <div className="mt-5 grid grid-cols-3 gap-2">
                    {[
                      {
                        label: "Protein",
                        value: Math.round(
                          days.reduce((s, d) => s + d.totalProteinG, 0) /
                            Math.max(days.length, 1)
                        ),
                        unit: "g",
                      },
                      {
                        label: "Carbs",
                        value: Math.round(
                          days.reduce((s, d) => s + d.totalCarbsG, 0) /
                            Math.max(days.length, 1)
                        ),
                        unit: "g",
                      },
                      {
                        label: "Fat",
                        value: Math.round(
                          days.reduce((s, d) => s + d.totalFatG, 0) /
                            Math.max(days.length, 1)
                        ),
                        unit: "g",
                      },
                    ].map((macro) => (
                      <div
                        key={macro.label}
                        className="rounded-lg bg-slate-50 p-3"
                      >
                        <p className="text-xs font-semibold text-muted">
                          {macro.label}
                        </p>
                        <p className="mt-1 text-lg font-bold text-ink">
                          {macro.value}
                          {macro.unit}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-100 bg-amber-50">
                <CardContent>
                  <div className="flex gap-3">
                    <TriangleAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" />
                    <div>
                      <p className="font-bold text-amber-950">
                        Allergy safety section
                      </p>
                      <p className="mt-2 text-sm leading-6 text-amber-900">
                        Semua makanan sudah difilter berdasarkan alergi
                        profilmu. Tidak suka satu makanan? Klik kartu makanan
                        dan pilih &quot;Alternative meal&quot;.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <MacroDistributionCard summary={mockNutritionSummary} />
            </div>
          </div>
        )}
      </div>
      {selectedMeal ? (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end justify-center bg-ink/55 p-0 backdrop-blur-sm sm:items-center sm:p-4"
        >
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-lg bg-white shadow-soft sm:rounded-lg">
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white/95 p-4 backdrop-blur">
              <div>
                <Badge variant="blue">{selectedMeal.type}</Badge>
                <h2 className="mt-2 text-xl font-bold text-ink">
                  {selectedMeal.name}
                </h2>
              </div>
              <Button
                size="icon"
                variant="ghost"
                aria-label="Close meal details"
                onClick={() => setSelectedMeal(null)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="p-5 sm:p-6">
              <div className="grid grid-cols-4 gap-2 text-center">
                {[
                  ["Calories", selectedMeal.calories],
                  ["Protein", `${selectedMeal.protein}g`],
                  ["Carbs", `${selectedMeal.carbs}g`],
                  ["Fat", `${selectedMeal.fat}g`],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-lg bg-slate-50 p-3">
                    <p className="text-xs font-semibold text-muted">{label}</p>
                    <p className="mt-1 text-sm font-bold text-ink">{value}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6 rounded-lg border border-brand-100 bg-brand-50 p-4">
                <div className="flex gap-3">
                  <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-brand-700" />
                  <div>
                    <h3 className="font-bold text-brand-950">
                      Allergy analysis
                    </h3>
                    <p className="mt-2 text-sm leading-6 text-brand-900">
                      {selectedMeal.allergyAnalysis}
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-4 rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
                <div className="flex gap-3">
                  <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-amber-500" />
                  <div>
                    <h3 className="font-bold text-ink">Why this meal fits you</h3>
                    <p className="mt-2 text-sm leading-6 text-muted">
                      {selectedMeal.fitReason}
                    </p>
                  </div>
                </div>
              </div>
              <Button
                className="mt-6 w-full"
                variant="secondary"
                disabled={swappingId === selectedMeal.id}
                onClick={() => handleSwap(selectedMeal.id)}
              >
                <RefreshCcw className="h-5 w-5" />
                {swappingId === selectedMeal.id
                  ? "Mencari alternatif..."
                  : "Alternative meal"}
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </DashboardShell>
  );
}
