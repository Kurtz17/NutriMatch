"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, ShieldCheck } from "lucide-react";
import { OnboardingStepper } from "@/components/onboarding/OnboardingStepper";
import { ActivityCard } from "@/components/profile/ActivityCard";
import { AllergyCard } from "@/components/profile/AllergyCard";
import { GoalCard } from "@/components/profile/GoalCard";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import type { ActivityLevel, DietGoal, Gender } from "@/types";

interface ApiAllergen {
  id: string;   
  name: string; 
  slug: string; 
}

const steps = ["Personal", "Body", "Goal", "Allergies"];
const activityLevels: ActivityLevel[] = ["Sedentary", "Light", "Moderate", "Very Active"];
const goals: DietGoal[] = ["Lose weight", "Maintain weight", "Gain weight"];
const genders: Gender[] = ["Female", "Male"];
const genderMap: Record<string, string> = { Female: "FEMALE", Male: "MALE" };
const activityMap: Record<string, string> = {
  Sedentary: "SEDENTARY",
  Light: "LIGHTLY_ACTIVE",
  Moderate: "MODERATELY_ACTIVE",
  "Very Active": "VERY_ACTIVE",
};
const goalMap: Record<string, string> = {
  "Lose weight": "LOSE_WEIGHT",
  "Maintain weight": "MAINTAIN_WEIGHT",
  "Gain weight": "GAIN_WEIGHT",
};

const initialForm = {
  name: "",
  age: 22,
  gender: "Male" as Gender,
  heightCm: 170,
  weightKg: 65,
  activityLevel: "Moderate" as ActivityLevel,
  dietGoal: "Maintain weight" as DietGoal,
  allergenIds: [] as string[], 
};

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState(initialForm);
  const [allergens, setAllergens] = useState<ApiAllergen[]>([]);
  const [loading, setLoading] = useState(false);
  const [checkingProfile, setCheckingProfile] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    fetch("/api/profile")
      .then((res) => {
        if (res.ok) {
          router.push("/dashboard");
        } else {
          setCheckingProfile(false);
        }
      })
      .catch(() => setCheckingProfile(false));
  }, [router]);
  useEffect(() => {
    fetch("/api/allergens")
      .then((res) => res.json())
      .then((data) => setAllergens(data.allergens ?? []))
      .catch(() => setAllergens([]));
  }, []);

  const toggleAllergen = (id: string) => {
    setForm((current) => ({
      ...current,
      allergenIds: current.allergenIds.includes(id)
        ? current.allergenIds.filter((a) => a !== id)
        : [...current.allergenIds, id],
    }));
  };

  const goNext = async () => {
    setError("");

    if (step === 1 && (!form.name || form.name.trim() === "")) {
      setError("Nama wajib diisi sebelum melanjutkan.");
      return;
    }

    if (step === steps.length) {
      setLoading(true);
      try {
        const res = await fetch("/api/profile", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: form.name,
            age: form.age,
            weightKg: form.weightKg,
            heightCm: form.heightCm,
            gender: genderMap[form.gender],
            activityLevel: activityMap[form.activityLevel],
            healthGoal: goalMap[form.dietGoal],
            allergenIds: form.allergenIds,
          }),
        });

        const data = await res.json();

        if (!res.ok) {
          setError(data.error ?? "Gagal menyimpan profil");
          setLoading(false);
          return;
        }
        await fetch("/api/meal-plan", { method: "POST" });

        router.push("/dashboard");
        router.refresh();
      } catch {
        setError("Terjadi kesalahan koneksi server. Coba lagi.");
        setLoading(false);
      }
      return;
    }

    setStep((current) => current + 1);
  };

  if (checkingProfile) {
    return <div className="py-24 text-center text-sm text-muted">Memeriksa status akun...</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <main className="app-container py-8 sm:py-10">
        <div className="mx-auto max-w-5xl">
          <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-sm font-semibold text-brand-700">Onboarding</p>
              <h1 className="mt-2 text-3xl font-bold tracking-normal text-ink">Build your nutrition profile</h1>
            </div>
            <p className="text-sm font-bold text-slate-500">Step {step} of {steps.length}</p>
          </div>

          <OnboardingStepper steps={steps} currentStep={step} />

          {error && (
            <div className="mt-6 rounded-lg bg-red-50 border border-red-100 p-4">
              <p className="text-sm font-semibold text-red-700">{error}</p>
            </div>
          )}

          <Card className="mt-5">
            <CardContent className="p-5 sm:p-7">
              {step === 1 ? (
                <div>
                  <h2 className="text-2xl font-bold text-ink">Personal Information</h2>
                  <div className="mt-6 grid gap-4 md:grid-cols-3">
                    <Input label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                    <Input label="Age" type="number" value={form.age} onChange={(e) => setForm({ ...form, age: Number(e.target.value) })} required />
                    <label className="block">
                      <span className="mb-2 block text-sm font-semibold text-slate-700">Gender</span>
                      <select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value as Gender })} className="h-12 w-full rounded-lg border border-slate-200 bg-white px-4 text-sm text-ink outline-none">
                        {genders.map((g) => <option key={g}>{g}</option>)}
                      </select>
                    </label>
                  </div>
                </div>
              ) : null}

              {step === 2 ? (
                <div>
                  <h2 className="text-2xl font-bold text-ink">Body Profile</h2>
                  <div className="mt-6 grid gap-4 md:grid-cols-2">
                    <Input label="Height" type="number" value={form.heightCm} helper="Centimeters" onChange={(e) => setForm({ ...form, heightCm: e.target.value === "" ? ("" as unknown as number) : Number(e.target.value) })} required />
                    <Input label="Weight" type="number" value={form.weightKg} helper="Kilograms" onChange={(e) => setForm({ ...form, weightKg: e.target.value === "" ? ("" as unknown as number) : Number(e.target.value) })} required />
                  </div>
                  <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    {activityLevels.map((level) => (
                      <ActivityCard key={level} level={level} selected={form.activityLevel === level} onSelect={(lvl) => setForm({ ...form, activityLevel: lvl })} />
                    ))}
                  </div>
                </div>
              ) : null}

              {step === 3 ? (
                <div>
                  <h2 className="text-2xl font-bold text-ink">Nutrition Goal</h2>
                  <div className="mt-6 grid gap-3 md:grid-cols-3">
                    {goals.map((goal) => (
                      <GoalCard key={goal} goal={goal} selected={form.dietGoal === goal} onSelect={(g) => setForm({ ...form, dietGoal: g })} />
                    ))}
                  </div>
                </div>
              ) : null}

              {step === 4 ? (
                <div>
                  <h2 className="text-2xl font-bold text-ink">Allergy Selection</h2>
                  <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    {allergens.map((allergen) => (
                      <AllergyCard
                        key={allergen.id}
                        allergy={{ id: allergen.id, label: allergen.name, slug: allergen.slug, description: "" }}
                        selected={form.allergenIds.includes(allergen.id)}
                        onToggle={() => toggleAllergen(allergen.id)}
                      />
                    ))}
                  </div>
                </div>
              ) : null}
            </CardContent>
          </Card>

          <div className="mt-5 flex justify-between gap-3">
            <Button variant="outline" disabled={step === 1 || loading} onClick={() => setStep((c) => c - 1)}>
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
            <Button onClick={goNext} disabled={loading}>
              {step === steps.length ? (loading ? "Menyimpan..." : "Complete profile") : "Continue"}
              {!loading && <ArrowRight className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}