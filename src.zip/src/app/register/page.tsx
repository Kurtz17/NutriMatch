"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Mail, LockKeyhole, UserPlus, UserRound } from "lucide-react";
import { AuthAside } from "@/components/auth/AuthAside";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (form.password !== form.confirmPassword) {
      setError("Password dan konfirmasi password tidak sama");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          password: form.password,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Registrasi gagal");
        return;
      }

      // Berhasil → arahkan ke onboarding untuk mengisi profil fisik
      router.push("/onboarding");
    } catch {
      setError("Terjadi kesalahan. Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      <main className="grid min-h-[calc(100vh-64px)] gap-6 p-4 lg:grid-cols-[1fr_0.95fr]">
        <section className="flex items-center justify-center py-10">
          <Card className="w-full max-w-md">
            <CardContent className="p-6 sm:p-8">
              <div className="mb-8">
                <p className="text-sm font-semibold text-brand-700">
                  Create account
                </p>
                <h1 className="mt-2 text-3xl font-bold tracking-normal text-ink">
                  Start your nutrition profile
                </h1>
                <p className="mt-3 text-sm leading-6 text-muted">
                  Register to generate allergy-safe meal recommendations.
                </p>
              </div>

              <form className="space-y-4" onSubmit={handleSubmit}>
                <Input
                  label="Name"
                  placeholder="Your name"
                  icon={<UserRound className="h-4 w-4" />}
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                />
                <Input
                  label="Email"
                  type="email"
                  placeholder="you@example.com"
                  icon={<Mail className="h-4 w-4" />}
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                />
                <Input
                  label="Password"
                  type="password"
                  placeholder="Min. 6 karakter"
                  icon={<LockKeyhole className="h-4 w-4" />}
                  value={form.password}
                  onChange={(e) =>
                    setForm({ ...form, password: e.target.value })
                  }
                  required
                />
                <Input
                  label="Confirm password"
                  type="password"
                  placeholder="Ulangi password"
                  icon={<LockKeyhole className="h-4 w-4" />}
                  value={form.confirmPassword}
                  onChange={(e) =>
                    setForm({ ...form, confirmPassword: e.target.value })
                  }
                  required
                />

                {error && (
                  <p className="rounded-lg bg-red-50 px-4 py-2 text-sm font-semibold text-red-700">
                    {error}
                  </p>
                )}

                <Button
                  type="submit"
                  size="lg"
                  className="w-full"
                  disabled={loading}
                >
                  <UserPlus className="h-5 w-5" />
                  {loading ? "Mendaftar..." : "Register"}
                </Button>
              </form>

              <p className="mt-6 text-center text-sm text-muted">
                Already have an account?{" "}
                <Link href="/login" className="font-bold text-brand-700">
                  Login
                </Link>
              </p>
            </CardContent>
          </Card>
        </section>
        <AuthAside
          title="Healthy planning that respects what your body cannot eat."
          description="NutriMatch turns health profile inputs into clean nutrition summaries, safer meal plans, and clear recommendation context."
        />
      </main>
    </div>
  );
}
