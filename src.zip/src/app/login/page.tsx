"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { LogIn, Mail, LockKeyhole } from "lucide-react";
import { AuthAside } from "@/components/auth/AuthAside";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Login gagal");
        return;
      }
      const profileRes = await fetch("/api/profile");

      if (profileRes.status === 404) {
        router.push("/onboarding");
      } else {
        router.push("/dashboard");
      }
    } catch {
      setError("Terjadi kesalahan. Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      <main className="grid min-h-[calc(100vh-64px)] lg:grid-cols-2">
        <section className="flex items-center justify-center px-4 py-10">
          <Card className="w-full max-w-md">
            <CardContent className="p-6 sm:p-8">
              <div className="mb-8">
                <p className="text-sm font-semibold text-brand-700">
                  Welcome back
                </p>
                <h1 className="mt-2 text-3xl font-bold tracking-normal text-ink">
                  Login to NutriMatch
                </h1>
                <p className="mt-3 text-sm leading-6 text-muted">
                  Continue to your dashboard and weekly allergy-safe meal plan.
                </p>
              </div>

              <form className="space-y-4" onSubmit={handleSubmit}>
                <Input
                  label="Email"
                  type="email"
                  placeholder="you@example.com"
                  icon={<Mail className="h-4 w-4" />}
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                />
                <Input
                  label="Password"
                  type="password"
                  placeholder="Your password"
                  icon={<LockKeyhole className="h-4 w-4" />}
                  value={form.password}
                  onChange={(e) =>
                    setForm({ ...form, password: e.target.value })
                  }
                  required
                />

                {error && (
                  <p className="rounded-lg bg-red-50 px-4 py-2 text-sm font-semibold text-red-700">
                    {error}
                  </p>
                )}

                <Button
                  type="submit"
                  size="lg"
                  className="w-full"
                  disabled={loading}
                >
                  <LogIn className="h-5 w-5" />
                  {loading ? "Masuk..." : "Login"}
                </Button>
              </form>

              <p className="mt-6 text-center text-sm text-muted">
                New to NutriMatch?{" "}
                <Link href="/register" className="font-bold text-brand-700">
                  Create account
                </Link>
              </p>
            </CardContent>
          </Card>
        </section>
        <AuthAside
          title="Your dashboard keeps calories, macros, and allergy safety in one calm view."
          description="Generate a personalized 7-day meal plan that respects your allergies and nutrition goals."
          className="min-h-[calc(100vh-64px)] rounded-none"
        />
      </main>
    </div>
  );
}
