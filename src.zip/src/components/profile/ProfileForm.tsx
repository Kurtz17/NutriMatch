"use client";

import { useState, useEffect } from "react";
import { Save } from "lucide-react";
import type { ActivityLevel, DietGoal, Gender } from "@/types";
import { ActivityCard } from "@/components/profile/ActivityCard";
import { AllergyCard } from "@/components/profile/AllergyCard";
import { GoalCard } from "@/components/profile/GoalCard";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";

interface ApiAllergen {
  id: string;
  name: string;
  slug: string;
}

const activityLevels: ActivityLevel[] = ["Sedentary", "Light", "Moderate", "Very Active"];
const goals: DietGoal[] = ["Lose weight", "Maintain weight", "Gain weight"];
const genders: Gender[] = ["Female", "Male"];

const GENDER_REVERSE: Record<string, Gender> = { MALE: "Male", FEMALE: "Female" };
const ACTIVITY_REVERSE: Record<string, ActivityLevel> = {
  SEDENTARY: "Sedentary",
  LIGHTLY_ACTIVE: "Light",
  MODERATELY_ACTIVE: "Moderate",
  VERY_ACTIVE: "Very Active",
};
const GOAL_REVERSE: Record<string, DietGoal> = {
  LOSE_WEIGHT: "Lose weight",
  MAINTAIN_WEIGHT: "Maintain weight",
  GAIN_WEIGHT: "Gain weight",
};

const genderMap: Record<string, string> = { Female: "FEMALE", Male: "MALE" };
const activityMap: Record<string, string> = {
  Sedentary: "SEDENTARY",
  Light: "LIGHTLY_ACTIVE",
  Moderate: "MODERATELY_ACTIVE",
  "Very Active": "VERY_ACTIVE",
};
const goalMap: Record<string, string> = {
  "Lose weight": "LOSE_WEIGHT",
  "Maintain weight": "MAINTAIN_WEIGHT",
  "Gain weight": "GAIN_WEIGHT",
};

export function ProfileForm() {
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    age: 22,
    gender: "Male" as Gender,
    heightCm: 170,
    weightKg: 65,
    activityLevel: "Moderate" as ActivityLevel,
    dietGoal: "Maintain weight" as DietGoal,
    allergenIds: [] as string[],
  });

  const [allergens, setAllergens] = useState<ApiAllergen[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [profileRes, allergenRes] = await Promise.all([
          fetch("/api/profile"),
          fetch("/api/allergens"),
        ]);

        const allergenData = await allergenRes.json();
        setAllergens(allergenData.allergens ?? []);

        if (profileRes.ok) {
          const profileData = await profileRes.json();
          const p = profileData.profile;

          setProfile({
            name: p.user?.name ?? "",
            email: p.user?.email ?? "",
            age: p.age,
            gender: GENDER_REVERSE[p.gender] ?? "Male",
            heightCm: p.heightCm,
            weightKg: p.weightKg,
            activityLevel: ACTIVITY_REVERSE[p.activityLevel] ?? "Moderate",
            dietGoal: GOAL_REVERSE[p.healthGoal] ?? "Maintain weight",
            allergenIds: p.allergies?.map((a: { allergenId: string }) => a.allergenId) ?? [],
          });
        }
      } catch {
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const toggleAllergen = (id: string) => {
    setStatus("idle");
    setProfile((current) => ({
      ...current,
      allergenIds: current.allergenIds.includes(id)
        ? current.allergenIds.filter((a) => a !== id)
        : [...current.allergenIds, id],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setStatus("idle");
    setErrorMsg("");

    try {
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: profile.name,
          age: profile.age,
          weightKg: profile.weightKg,
          heightCm: profile.heightCm,
          gender: genderMap[profile.gender],             
          activityLevel: activityMap[profile.activityLevel],
          healthGoal: goalMap[profile.dietGoal],
          allergenIds: profile.allergenIds,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data.error ?? "Gagal menyimpan perubahan");
        setStatus("error");
        return;
      }
      setStatus("success");
    } catch {
      setErrorMsg("Terjadi kesalahan server.");
      setStatus("error");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="py-12 text-center text-sm text-muted">Memuat profil...</div>;

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      <Card><CardContent>
        <div className="mb-6"><h2 className="text-xl font-bold text-ink">Personal information</h2></div>
        <div className="grid gap-4 md:grid-cols-2">
          <Input label="Name" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
          <Input label="Email" value={profile.email} readOnly />
          <Input label="Age" type="number" value={profile.age} onChange={(e) => setProfile({ ...profile, age: Number(e.target.value) })} />
          <label className="block">
            <span className="mb-2 block text-sm font-semibold text-slate-700">Gender</span>
            <select value={profile.gender} onChange={(e) => setProfile({ ...profile, gender: e.target.value as Gender })} className="h-12 w-full rounded-lg border border-slate-200 bg-white px-4 text-sm text-ink outline-none">
              {genders.map((g) => <option key={g}>{g}</option>)}
            </select>
          </label>
        </div>
      </CardContent></Card>

      <Card><CardContent>
        <div className="mb-6"><h2 className="text-xl font-bold text-ink">Measurements and activity</h2></div>
        <div className="grid gap-4 md:grid-cols-2">
          <Input label="Height" type="number" value={profile.heightCm} helper="Centimeters" onChange={(e) => setProfile({ ...profile, heightCm: Number(e.target.value) })} />
          <Input label="Weight" type="number" value={profile.weightKg} helper="Kilograms" onChange={(e) => setProfile({ ...profile, weightKg: Number(e.target.value) })} />
        </div>
        <div className="mt-5 grid gap-3 md:grid-cols-4">
          {activityLevels.map((level) => (
            <ActivityCard key={level} level={level} selected={profile.activityLevel === level} onSelect={(lvl) => setProfile({ ...profile, activityLevel: lvl })} />
          ))}
        </div>
      </CardContent></Card>

      <Card><CardContent>
        <div className="mb-6"><h2 className="text-xl font-bold text-ink">Nutrition target</h2></div>
        <div className="grid gap-3 md:grid-cols-3">
          {goals.map((goal) => (
            <GoalCard key={goal} goal={goal} selected={profile.dietGoal === goal} onSelect={(g) => setProfile({ ...profile, dietGoal: g })} />
          ))}
        </div>
      </CardContent></Card>

      <Card><CardContent>
        <div className="mb-6"><h2 className="text-xl font-bold text-ink">Allergy preferences</h2></div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {allergens.map((allergen) => (
            <AllergyCard
              key={allergen.id}
              allergy={{ id: allergen.id, label: allergen.name, slug: allergen.slug, description: "" }}
              selected={profile.allergenIds.includes(allergen.id)}
              onToggle={() => toggleAllergen(allergen.id)}
            />
          ))}
        </div>
      </CardContent></Card>

      <div className="flex flex-col items-stretch justify-between gap-3 sm:flex-row sm:items-center">
        <p className="text-sm font-semibold">
          {status === "success" && <span className="text-green-700">✓ Perubahan berhasil disimpan</span>}
          {status === "error" && <span className="text-red-700">{errorMsg}</span>}
        </p>
        <Button type="submit" size="lg" disabled={saving}>
          <Save className="h-5 w-5" />
          {saving ? "Menyimpan..." : "Save changes"}
        </Button>
      </div>
    </form>
  );
}